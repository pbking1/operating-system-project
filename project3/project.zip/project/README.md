###project 3
	by bin peng and Nhan Do
####FIFO
	done by bin peng
- this part is using the FIFO page replacement algorithm
- due to the description of the project3 has no sample input and output
	- I generate the data of the process random 
	- and store in a list
- and I create a deque to store all the current page
	- and in my code, we can have 3 in the same time 
	- and will pop the front page and push the newest one into deque
- and the output of the program will show what I get
- also I will output the hit rate after "FIFO end"

#####how to run 
- use 'make' and './project3'
