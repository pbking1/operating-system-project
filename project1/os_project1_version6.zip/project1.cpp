#include<iostream>
#include<cstring>
#include<typeinfo>
#include<string>
#include<fstream>
#include<algorithm>
#include<vector>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#include<queue>
#include<deque>
using namespace std;

typedef struct Node{
	int pid;
	int arrive_t;
	int burst_t;
	int remain_t;
	int wait_t;
	int current_flag;
	int priority;
}PCB;

//define the time and other parameters
//The time for waiting to execute 
double aver_waiting_time;
//reponse time = waiting time + request service time
double aver_response_time;
//turn_around time = response time + waiting time
double aver_turn_around_time;

int get_filerow(char *a){
	ifstream fin;
	string line;
	int counter = 0;
	fin.open(a);
	if(fin){
		while(getline(fin, line, '\n')){
			counter++;
		}
		fin.close();
	}
	return counter;
}

PCB jobs[20];
void import_data(char *a){
	int i = 0, j = 0;
	string line;
	int b;
	ifstream in(a);
	char c;
	int row_number = 3 * get_filerow(a);
	int array_store[row_number];
	for(i = 0; i < row_number; i++)
		array_store[i] = 0;
	//read file
	for(i = 0; i < row_number; i++){
		in>>b;
		c = in.peek();
		if('\t' == c){
			break;
		}
		array_store[j] = b;
		j++;
	}
	for(i = 0, j = 0; i < row_number; ){
		jobs[j].pid = array_store[i];
		jobs[j].arrive_t = array_store[i + 1];
		jobs[j].burst_t = array_store[i + 2];
		jobs[j].remain_t = 0;
		jobs[j].wait_t = 0;
		jobs[j].current_flag = 0;
		j++;
		i += 3;
	}
	in.close();
}

bool compare_SJF(PCB a, PCB b){
	if(a.arrive_t == b.arrive_t){
		return a.burst_t < b.burst_t;
	}
	return a.arrive_t < b.arrive_t;
}

bool compare_SRJF(PCB a, PCB b){
	return a.burst_t < b.burst_t;
}

bool compare_FCFS(PCB a, PCB b){
	return a.arrive_t < b.arrive_t;
}

//bug need to fix the arrive time
void SJF(char *a){
	import_data(a);
	vector<PCB> job(get_filerow(a));
	for(int j = 0; j < get_filerow(a); j++){
		job[j].pid = jobs[j].pid;
		job[j].arrive_t = jobs[j].arrive_t;
		job[j].burst_t = jobs[j].burst_t;
	}
	sort(job.begin(), job.end(), compare_SJF);	
	
	//SJF algorithm begin	
	int counter = 0;
	int process_num = get_filerow(a);
	cout<<"Total "<<process_num<<" tasks are read from "<<a<<endl;
	cout<<"press 'enter' to start"<<endl;
	cout<<"==================================================="<<endl;
	//pause the program
	cin.get();

	//if all the process arrive in the same time in the beginning
	//test in input.3
	int samet_flag = 0;
	for(int i = 0; i < process_num; i++)
		samet_flag += job[i].arrive_t;
	if(samet_flag == 0){
		for(int i = 0; i < process_num; i++){
			for(int j = 0; j < job[i].burst_t; j++){
				cout<<"<system time "<<counter<<"> process "<<job[i].pid<<" is running"<<endl;
				counter++;
			}
			cout<<"<system time "<<counter<<"> process "<<job[i].pid<<" finished......"<<endl;
		}
		cout<<"<system time "<<counter<<"> All process finished......."<<endl;
	}else{
		//if the process are not coming in the same time
		cout<<"Not all the process arrive at the same time"<<endl;	
		int flag = 100;
		while(flag != 0){
			//pause the program
			//cin.get();
			//if all process are done
			int done_flag = 0;
			for(int i = 0; i < process_num; i++){
				done_flag += job[i].burst_t;
			}
			if(done_flag == 0){
				break;
			}
			//not until all the process are done
			flag = 0;
			for(int i = 0; i < process_num; i++){
				flag += job[i].burst_t;
			}
			//sort(job.begin(), job.end(), compare_SJF);
			//time counter ++
			counter++;
			//if the process comes
			int current_process_num = 0;
			for(int j = 0; j < process_num; j++){
				if(counter > job[j].arrive_t){
					job[j].current_flag = 1;
					//current_process_num++;
				}
			}
			//calculate the current process number
			for(int i = 0; i < process_num; i++){
				if(job[i].burst_t > 0 && job[i].current_flag == 1){
					current_process_num++;
				}

			}
			if(current_process_num > 0){
				vector<PCB> current_process(current_process_num);
				//copy the current process to the vector
				for(int i = 0, j = 0; i < process_num; i++){
					if(job[i].current_flag == 1){
						if(job[i].burst_t > 0){
							current_process[j].pid = job[i].pid;
							current_process[j].arrive_t = job[i].arrive_t;
							current_process[j].burst_t = job[i].burst_t;
							j++;
						}
					}
				}
				//sort the current_process
				sort(current_process.begin(), current_process.end(), compare_SRJF);
				cout<<endl;
				//the vector after sort
				/*for(int i = 0; i < current_process_num; i++){
					cout<<current_process[i].pid<<" "<<current_process[i].arrive_t<<" "<<current_process[i].burst_t<<endl;
				}*/
				//earse the leading 0
				vector<PCB>::iterator iter;
				while(current_process[0].pid <= 0){
					iter = current_process.begin();
					current_process.erase(iter);
				}
				//substract the burst time in the value of 1
				if(current_process[0].pid != 0){
					cout<<"<system time "<<counter<<"> process "<<current_process[0].pid<<" is running";
					current_process[0].burst_t -= 1;
					if(current_process[0].burst_t == 0){
						cout<<endl<<"<system time "<<counter<<"> process "<<current_process[0].pid<<" is finished........";
					}
				}
				
				for(int i = 0; i < process_num; i++){
					for(int j = 0; j < current_process_num; j++){
						if(job[i].pid == current_process[j].pid){
							if(current_process[j].burst_t >= 0){
								job[i].burst_t = current_process[j].burst_t;
							}
						}
					}
				}
			}
		}
	}

	cout<<"\n==================================================="<<endl; 
	
	cout<<"Average cpu usage: "<<endl;
	cout<<"Average waiting time: "<<endl;
	cout<<"Average response time: "<<endl;
	cout<<"Average turnaround time: "<<endl;
	cout<<"==================================================="<<endl; 
}

void FCFS(char *a){
	import_data(a);
	vector<PCB> job(get_filerow(a));
	for(int j = 0; j < get_filerow(a); j++){
		job[j].pid = jobs[j].pid;
		job[j].arrive_t = jobs[j].arrive_t;
		job[j].burst_t = jobs[j].burst_t;
	}
	//FCFS algorithm begin
	int counter = 0;
	int cpu_count = 0, cpu_all = 0;
	int process_num = get_filerow(a);
	cout<<"Total "<<process_num<<" tasks are read from "<<a<<endl;
	cout<<"press 'enter' to start"<<endl;
	cout<<"==================================================="<<endl;
	//pause the program
	cin.get();
	//calculate the time
	aver_waiting_time = 0;
	aver_response_time = 0;
	aver_turn_around_time = 0;
	sort(job.begin(), job.end(), compare_FCFS); 
	for(int i = 0; i < process_num; i++){
		for(int j = 0; j < job[i].burst_t; j++){
			cout<<"<system time "<<counter<<"> process "<<job[i].pid<<" is running"<<endl;
			counter++;
			//if the jobs are done and the next job is not arriving
			//increase the counter of cpu
			if(job[i+1].arrive_t > counter)
				cpu_count++;
		}
		cout<<"<system time "<<counter<<"> process "<<job[i].pid<<" finished......"<<endl;
	}
	cout<<"<system time "<<counter<<"> All process finished......."<<endl;
	cout<<"==================================================="<<endl; 
	//get the cpu usage time
	cpu_all = counter;
	cout<<"Average cpu usage: "<<100*(((double)cpu_all-(double)cpu_count)/(double)cpu_all)<<"%"<<endl;
	cout<<"Average waiting time: "<<aver_waiting_time<<endl;
	cout<<"Average response time: "<<aver_response_time<<endl;
	cout<<"Average turnaround time: "<<aver_turn_around_time<<endl;
	cout<<"==================================================="<<endl; 
}

void RR(char *a, double quan){
	import_data(a);
	vector<PCB> job(get_filerow(a));
	for(int j = 0; j < get_filerow(a); j++){
		job[j].pid = jobs[j].pid;
		job[j].arrive_t = jobs[j].arrive_t;
		job[j].burst_t = jobs[j].burst_t;
	}
	//RR algorithm begin
	int _round = int(quan); //quan time
	int counter = 0;
	int process_num = get_filerow(a);
	cout<<"Total "<<process_num<<" tasks are read from "<<a<<endl;
	cout<<"press 'enter' to start"<<endl;
	cout<<"==================================================="<<endl;
	//pause the program
	cin.get();
	//use a queue to store the current process
	//and give the time slice to the top 
	//and after the top finish, let the new comer pump in the queue
	//then pop the top process, and then pump into the back(if the burst time is not zero)
	deque<PCB> current_proces;
	PCB temp;
	temp.pid = temp.arrive_t = temp.burst_t = 0;
	while(1){
		int done_flag = 0;
		for(int i = 0; i < process_num; i++)
			done_flag += job[i].burst_t;
		if(done_flag == 0)
			break;
		//time counter ++
		counter++;
		for(int i = 0; i < process_num; i++){
			if(counter >= job[i].arrive_t)
				if(job[i].current_flag != 1){
					job[i].current_flag = 1;
					//find out the current time which process is coming
					//and add to the deque
					current_proces.push_back(job[i]);
				}
		}
		counter--;
		if(temp.burst_t > 0)
			current_proces.push_back(temp);
		deque<PCB>::iterator iter = current_proces.begin();
		//renew the deque
		for(int i = 0; i < process_num; i++){
			if( (*iter).pid == job[i].pid)
				(*iter).burst_t = job[i].burst_t;
		}

		if( (*iter).burst_t < _round){
			int n1 = (*iter).burst_t;
			//cout<<"aaaa "<<n1<<endl;
			for(int j = 0; j < n1; j++){
				cout<<"<system time "<<counter<<" >"<<(*iter).pid<<" is running";
				//cout<<endl;
				for(int i = 0; i < process_num; i++){
					if((*iter).pid == job[i].pid){
						--job[i].burst_t;
						if(job[i].burst_t == 0){
							cout<<endl<<"<system time "<<counter<<" >"<<(*iter).pid<<" is finished......"<<endl;
						}
						break;
					}
				}
				counter++;
			}
		}else{
			int n1 = _round;
			//cout<<"bbbb "<<n1<<endl;
			while(n1--){
				cout<<"<system time "<<counter<<" >"<<(*iter).pid<<" is running";
				cout<<endl;
				for(int i = 0; i < process_num; i++){
					if( (*iter).pid == job[i].pid){
						--job[i].burst_t;
						if(job[i].burst_t == 0){
							cout<<"<system time "<<counter<<" >"<<(*iter).pid<<" is finished......"<<endl; 
						}
						break;
					}
				}
				counter++;
			}
		}
		//cout<<endl;
		PCB front_process = current_proces.front();
		current_proces.pop_front();
		temp = front_process;
		//if(front_process.burst_t > 0){
		//	current_proces.push_back(front_process);
		//}
		/*for(int i = 0; i < process_num; i++){
			cout<<job[i].pid<<" "<<job[i].arrive_t<<" "<<job[i].burst_t<<endl;
		}*/
	}

	cout<<"<system time "<<counter<<"> All process finished......."<<endl;	
	cout<<"==================================================="<<endl; 
	cout<<"Average cpu usage: "<<endl;
	cout<<"Average waiting time: "<<endl;
	cout<<"Average response time: "<<endl;
	cout<<"Average turnaround time: "<<endl;
	cout<<"==================================================="<<endl;
}

void import_data_version2(char *a){
	int i = 0, j = 0;
	string line;
	int b;
	ifstream in(a);
	char c;
	int row_number = 4 * get_filerow(a);
	int array_store[row_number];
	for(i = 0; i < row_number; i++)
		array_store[i] = 0;
	//read file
	for(i = 0; i < row_number; i++){
		in>>b;
		c = in.peek();
		if('\t' == c){
			break;
		}
		array_store[j] = b;
		j++;
	}
	for(i = 0, j = 0; i < row_number; ){
		jobs[j].pid = array_store[i];
		jobs[j].arrive_t = array_store[i + 1];
		jobs[j].burst_t = array_store[i + 2];
		jobs[j].priority = array_store[i + 3];
		jobs[j].remain_t = 0;
		jobs[j].wait_t = 0;
		jobs[j].current_flag = 0;

		j++;
		i += 4;
	}
	in.close();
}

bool compare_PRIO(PCB a, PCB b){
	return a.priority > b.priority;
}

void PRIO(char *a){
	//this priority scheduling is preemptive
	import_data_version2(a);
	vector<PCB> job(get_filerow(a));
	for(int j = 0; j < get_filerow(a); j++){
		job[j].pid = jobs[j].pid;
		job[j].arrive_t = jobs[j].arrive_t;
		job[j].burst_t = jobs[j].burst_t;
		job[j].priority = jobs[j].priority;
		//cout<<job[j].pid<<" "<<job[j].arrive_t<<" "<<job[j].burst_t<<" "<<job[j].priority<<endl;
	}
	//PRIO algorithm begin	
	int counter = 0;
	int process_num = get_filerow(a);
	cout<<"Total "<<process_num<<" tasks are read from "<<a<<endl;
	cout<<"press 'enter' to start"<<endl;
	cout<<"==================================================="<<endl;
	//pause the program
	cin.get();
	while(1){
		int done_flag = 0;
		for(int i = 0; i < process_num; i++){
			done_flag += job[i].burst_t;
		}
		if(done_flag == 0)
			break;
		//time counter increase
		counter++;
		//calculate the current process
		int current_process_num = 0;
		for(int j = 0; j < process_num; j++){
			if(counter > job[j].arrive_t)
				job[j].current_flag = 1;
		}
		for(int i = 0; i < process_num; i++){
			if(job[i].burst_t > 0 && job[i].current_flag == 1)
				current_process_num++;
		}
		if(current_process_num > 0){
			vector<PCB> current_process(current_process_num);
			for(int i = 0, j = 0; i < process_num; i++){
				if(job[i].current_flag == 1){
					if(job[i].burst_t > 0){
						current_process[j].pid = job[i].pid;
						current_process[j].arrive_t = job[i].arrive_t;
						current_process[j].burst_t = job[i].burst_t;
						current_process[j].priority = job[i].priority;
						j++;
					}
				}
			}
			sort(current_process.begin(), current_process.end(), compare_PRIO);
			cout<<endl;
			//earse the leading zero
			vector<PCB>::iterator iter;
			while(current_process[0].pid <= 0){
				iter = current_process.begin();
				current_process.erase(iter);
			}
			if(current_process[0].pid != 0){
				if(current_process[0].burst_t > 0){
					cout<<"<system time "<<counter<<"> process "<<current_process[0].pid<<" is running";
					current_process[0].burst_t -= 1;
				}
				if(current_process[0].burst_t <= 0){
					cout<<endl<<"<system time "<<counter<<"> process "<<current_process[0].pid<<" is finished........";
				}
			}
			for(int i = 0; i < process_num; i++){
				for(int j = 0; j < current_process_num; j++){
					if(job[i].pid == current_process[j].pid){
						if(current_process[j].burst_t >= 0){
							job[i].burst_t = current_process[j].burst_t;
						}
					}
				}
			}
		}
	}
	cout<<"<system time "<<counter<<"> All process finished......."<<endl;
	cout<<"\n==================================================="<<endl; 
	
	cout<<"Average cpu usage: "<<endl;
	cout<<"Average waiting time: "<<endl;
	cout<<"Average response time: "<<endl;
	cout<<"Average turnaround time: "<<endl;
	cout<<"==================================================="<<endl; 
}

bool compare_PRIO_NON(PCB a, PCB b){
	if(a.arrive_t == b.arrive_t)
		return a.priority > b.priority;
	return a.arrive_t < b.arrive_t;
}

void PRIO_NON(char *a){
	//this priority scheduling is preemptive
	import_data_version2(a);
	vector<PCB> job(get_filerow(a));
	for(int j = 0; j < get_filerow(a); j++){
		job[j].pid = jobs[j].pid;
		job[j].arrive_t = jobs[j].arrive_t;
		job[j].burst_t = jobs[j].burst_t;
		job[j].priority = jobs[j].priority;
		//cout<<job[j].pid<<" "<<job[j].arrive_t<<" "<<job[j].burst_t<<" "<<job[j].priority<<endl;
	}
	//PRIO algorithm begin	
	int counter = 0;
	int process_num = get_filerow(a);
	cout<<"Total "<<process_num<<" tasks are read from "<<a<<endl;
	cout<<"press 'enter' to start"<<endl;
	cout<<"==================================================="<<endl;
	//pause the program
	cin.get();
	while(1){
		int done_flag = 0;
		for(int i = 0; i < process_num; i++){
			done_flag += job[i].burst_t;
		}
		if(done_flag == 0)
			break;
		//time counter increase
		counter++;
		//calculate the current process
		int current_process_num = 0;
		for(int j = 0; j < process_num; j++){
			if(counter > job[j].arrive_t)
				job[j].current_flag = 1;
		}
		for(int i = 0; i < process_num; i++){
			if(job[i].burst_t > 0 && job[i].current_flag == 1)
				current_process_num++;
		}
		if(current_process_num > 0){
			vector<PCB> current_process(current_process_num);
			for(int i = 0, j = 0; i < process_num; i++){
				if(job[i].current_flag == 1){
					if(job[i].burst_t > 0){
						current_process[j].pid = job[i].pid;
						current_process[j].arrive_t = job[i].arrive_t;
						current_process[j].burst_t = job[i].burst_t;
						current_process[j].priority = job[i].priority;
						j++;
					}
				}
			}
			sort(current_process.begin(), current_process.end(), compare_PRIO_NON);
			cout<<endl;
			//earse the leading zero
			vector<PCB>::iterator iter;
			while(current_process[0].pid <= 0){
				iter = current_process.begin();
				current_process.erase(iter);
			}
			if(current_process[0].pid != 0){
				if(current_process[0].burst_t > 0){
					cout<<"<system time "<<counter<<"> process "<<current_process[0].pid<<" is running";
					current_process[0].burst_t -= 1;
				}
				if(current_process[0].burst_t <= 0){
					cout<<endl<<"<system time "<<counter<<"> process "<<current_process[0].pid<<" is finished........";
				}
			}
			for(int i = 0; i < process_num; i++){
				for(int j = 0; j < current_process_num; j++){
					if(job[i].pid == current_process[j].pid){
						if(current_process[j].burst_t >= 0){
							job[i].burst_t = current_process[j].burst_t;
						}
					}
				}
			}
		}
	}
	cout<<"<system time "<<counter<<"> All process finished......."<<endl;
	cout<<"\n==================================================="<<endl; 
	
	cout<<"Average cpu usage: "<<endl;
	cout<<"Average waiting time: "<<endl;
	cout<<"Average response time: "<<endl;
	cout<<"Average turnaround time: "<<endl;
	cout<<"==================================================="<<endl; 
}
int main(int argc, char *argv[]){

	if(strcmp(argv[2],"FCFS") == 0){
		cout<<"Scheduling algorithm: FCFS"<<endl;
		cout<<"The input file is "<<argv[1]<<endl;
		FCFS(argv[1]);
	}else if(strcmp(argv[2],"SJF") == 0){
		cout<<"Scheduling algorithm: SJF"<<endl;
		cout<<"The input file is "<<argv[1]<<endl;
		SJF(argv[1]);
	}else if(strcmp(argv[2],"RR") == 0){
		cout<<"Scheduling algorithm: RR"<<endl;
		cout<<"The input file is "<<argv[1]<<endl;
		double qua = 0;;
		char *q;
		q = argv[3];
		double j;
		for(int i = 0; i < strlen(q); i++){
			j = pow(10, double(strlen(q) - 1 - i));
			qua += j * (q[i] - '0');
		}
		RR(argv[1], qua);
	}else if(strcmp(argv[2],"PRIO") == 0){
		cout<<"Scheduling algorithm: PRIO"<<endl;
		cout<<"The input file is "<<argv[1]<<endl;
		PRIO(argv[1]);
	}else if(strcmp(argv[2],"PRIO_NON") == 0){
		cout<<"Scheduling algorithm: PRIO_NON_PREEMPTIVE"<<endl;
		cout<<"The input file is "<<argv[1]<<endl;
		PRIO_NON(argv[1]);
	}else{
		cout<<"please enter the right parameter\n";
	}
	return 0;
}
