###Project 0
	bin peng

####project description
- The project is written in C 
- And implement the Circular Linked list
- After that, use the linked list to allocate resource to the processes

####brief description of the file
- linkedlist_c.c
	- The file contain the implemment the data structure of the circular linked list
	- And use the linked list to allocate resource
	- int the main function
		- I first create a list that have 10 processes
		- And than print the list out
		-  after that I allocate the resource to the processes
		- then print the list out to see the result
		- the search for a resource
		- then delete a resource from the process
		- then print the list out to see the delete result
		- finally free the pointer
- Makefile
	- used to compile the c file
	- simply type "make"
	- And then type "./project0" to run the program

