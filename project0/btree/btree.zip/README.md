###Project 0
	bin peng

####project description
- The project is written in C++ 
- And implement the binary search tree
- After that, use the binary search tree to allocate resource to the processes

####brief description of the file
- btree.cpp
	- The file contain the implemment the data structure of the binary search tree
	- And use the preorder traverse to allocate resource
	- int the main function
		- I first create a tree that have 10 processes
		- And than print the tree out
		- then print the tree out to see the result
		- the search for a resource
		- then delete a resource from the process
		- then print the table out to see the delete result
		- after that I allocate the resource to the processes
- Makefile
	- used to compile the cpp file
	- simply type "make"
	- And then type "./project0" to run the program
		- And then input 1 for search
		- input number 10 to increase the process number

